
HOW TO USE:
0. Close all Visual Studio instanses.
1. Remove other patches at first (Previous versions of this patch will be uninstalled automatically using current version).
2. Run it as administrator, overwise it'll tell you that you are not administrator.
3. The gui may be unresponsable a few minutes - it's ok.
4. Run this patch every time you installing/repairing DX controls.

TESTED PRODUCTS:
- WinForms
- ASP.Net
- WPF (Designer working in unlimited trial mode - no nag screens, application compiles sucessfully licensed) (If you don't understand, what that means, don't worry - its working)
- XAF
- CodeRush
- Dashboard
- Silverlight

UPD 16-06-2017:
- Added support for Visual Studio 2017 (only Community edition tested)
- Added support for DX 17.X versions
- Patch was updated to version 8.0
=================
www.linkerpt.com